package com.dwyingyuan.retry.enums;

import lombok.*;

@Getter
public enum RetryStatusEnums {
    DONE(1, "处理完毕/成功"),
    UN_DONE(0, "未处理/失败");

    private int code;
    private String desc;

    private RetryStatusEnums(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }


}