package com.dwyingyuan.retry.model.dto;

import lombok.*;

/**
 * 微信公众号：笛舞音缘
 * Created by andy  on 2021-01-04.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LookParamDTO {

    private String where;

    private String who;

    private Long time;
}
