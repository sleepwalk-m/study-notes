package com.dwyingyuan.retry.repository;

import com.dwyingyuan.retry.model.dto.*;

import java.util.*;

public interface RetryRepository {

    int insert(RetryDTO re);

    List<RetryDTO> findNeedRetry(Long maxId, Integer batchQueryLimitSize, Integer retryTimes);

    void increaseRetryTime(RetryDTO retryDTO);

    void markRetrySuccess(RetryDTO retryDTO);


}