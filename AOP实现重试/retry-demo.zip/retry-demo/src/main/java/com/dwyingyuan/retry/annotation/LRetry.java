package com.dwyingyuan.retry.annotation;

import java.lang.annotation.*;

/**
 * 微信公众号：笛舞音缘
 * Created by andy  on 2021-01-12.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface LRetry {

    /**
     * 重试次数
     *
     * @return
     */
    int retryTimes();


    /**
     * 是否需要持久化重试
     *
     * @return
     */
    boolean needJobRetry();
}
