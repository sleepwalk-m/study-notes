package com.dwyingyuan.retry.context;

public class RetryContext {
    public static ThreadLocal<Boolean> retryContext = new InheritableThreadLocal<Boolean>();

    public static void setContext(Boolean isExecuteAspect) {
        retryContext.set(isExecuteAspect);
    }

    public static void clear() {
        retryContext.remove();
    }
}