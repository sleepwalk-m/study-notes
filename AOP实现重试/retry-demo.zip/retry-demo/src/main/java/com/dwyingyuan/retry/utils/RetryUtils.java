package com.dwyingyuan.retry.utils;

import com.alibaba.fastjson.*;
import com.dwyingyuan.retry.exception.*;
import com.dwyingyuan.retry.model.dto.*;
import com.google.common.collect.*;
import org.apache.commons.lang3.*;
import org.aspectj.lang.*;

import java.lang.reflect.*;
import java.util.*;

public class RetryUtils {


    /**
     * 获取反射方法对象
     *
     * @param retryClass
     * @param className
     * @return
     * @throws RetryException
     */
    public static Method getMethod(RetryClass retryClass, String className) throws RetryException {
        Map<String, String> args = retryClass.getArgs();
        Class[] argTypes = new Class[args.keySet().size()];
        try {
            generateMethodArgTypes(args, argTypes);
            Class clazz = Class.forName(className);
            for (Class c : clazz.getInterfaces()) {
                try {
                    return c.getMethod(retryClass.getMethodName(), argTypes);
                } catch (NoSuchMethodException e) {

                }
            }
        } catch (ClassNotFoundException e) {
            throw new RetryException(String.format("classNotFount,argTypes:[%s]", retryClass.getArgs()), e);
        }
        throw new RetryException(String.format("NoSuchMethodException,argTypes:[%s]", argTypes));

    }

    /**
     * 封装入参类型
     *
     * @param args
     * @param argTypes
     * @throws ClassNotFoundException
     */
    private static void generateMethodArgTypes(Map<String, String> args, Class[] argTypes) throws ClassNotFoundException {
        for (int i = 0; i < args.keySet().size(); i++) {
            String name = (String) args.keySet().toArray()[i];
            Class c = ClassUtils.getClass(name);
            argTypes[i] = c;
        }
    }

    /**
     * 从 ApplicationContext 获取bean
     *
     * @param className
     * @return
     * @throws RetryException
     */
    public static Object getClassImpl(String className) throws RetryException {

        if (StringUtils.isBlank(className)) {
            throw new RetryException("className is blank");
        }
        if (Beans.getBean(className) == null) {
            throw new RetryException("can not find class");
        }
        return Beans.getBean(className);
    }


    /**
     * 获取入参
     *
     * @param retryClass
     * @return
     */
    public static Object[] getArgs(RetryClass retryClass) {

        Map<String, String> args = retryClass.getArgs();
        Class[] argTypes = new Class[args.keySet().size()];
        Object[] objects = new Object[args.keySet().size()];
        try {
            generateMethodArgTypes(args, argTypes);
        } catch (ClassNotFoundException e) {
            throw new RetryException(String.format("classNotFount,argTypes:[%s]", retryClass.getArgs()), e);
        }

        List<String> keys = Lists.newArrayList(args.keySet());
        for (int i = 0; i < keys.size(); i++) {
            objects[i] = JSON.parseObject(args.get(keys.get(i)), argTypes[i]);
        }
        return objects;

    }


    /**
     * 封装重试对象
     *
     * @param joinPoint
     * @param method
     * @param fullClazzName
     * @param className
     * @return
     */
    public static RetryClass generateRetryClass(ProceedingJoinPoint joinPoint, Method method, String fullClazzName, String className) {

        LinkedHashMap<String, String> args = new LinkedHashMap<>();
        RetryClass rc = RetryClass.builder()
                .className(className)
                .methodName(method.getName())
                .fullClassName(fullClazzName)
                .args(args)
                .build();
        Class<?>[] parameterTypes = method.getParameterTypes();

        if (parameterTypes.length == 0) {
            return rc;
        }

        for (int i = 0; i < parameterTypes.length; i++) {
            args.put(parameterTypes[i].getName(), JSON.toJSONString(joinPoint.getArgs()[i]));
        }
        rc.setArgs(args);
        return rc;
    }

}