package com.dwyingyuan.retry.config;

import com.github.dozermapper.core.*;
import org.springframework.context.annotation.*;

@Configuration
public class DozerConfiguration {

    @Bean
    public Mapper mapper() {
        DozerBeanMapper mapper = (DozerBeanMapper) DozerBeanMapperBuilder.buildDefault();
        return mapper;
    }
}