package com.dwyingyuan.retry.aop;

import com.alibaba.fastjson.*;
import com.dwyingyuan.retry.annotation.*;
import com.dwyingyuan.retry.context.*;
import com.dwyingyuan.retry.model.dto.*;
import com.dwyingyuan.retry.repository.*;
import com.dwyingyuan.retry.utils.*;
import lombok.extern.slf4j.*;
import org.apache.commons.lang3.*;
import org.aspectj.lang.*;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import java.lang.reflect.*;

/**
 * 微信公众号：笛舞音缘
 * Created by andy  on 2021-01-12.
 */
@Aspect
@Component
@Slf4j
public class RetryAspect {


    //2.定义切面类-打注解
    //2.1 切点表达式（注解）
    @Pointcut("@annotation(com.dwyingyuan.retry.annotation.LRetry)")
    public void retyPoint() {

    }

    //2.2编写通知（环绕）
    @Around("retyPoint()")
    public Object handle(ProceedingJoinPoint joinPoint) throws Throwable {
        //需不需进入切面重试
        if (RetryContext.retryContext.get() != null && !RetryContext.retryContext.get()) {
            return joinPoint.proceed();
        }

        //2.2.1 获取到注解对象
        Signature signature = joinPoint.getSignature();
        MethodSignature methodSignature = (MethodSignature) signature;
        Method method = methodSignature.getMethod();
        LRetry retry = method.getAnnotation(LRetry.class);
        //2.2.2 循环重试根据重试次数
        Throwable error = null;
        for (int i = 0; i < retry.retryTimes(); i++) {
            try {
                joinPoint.proceed();
            } catch (Throwable throwable) {
                error = throwable;
                log.error("方法：{} 进入第 {} 次重试！！！", method.getName(), i + 1, throwable);
            }
        }
        //todo 2.2.3 持久化重试参数
        persistenceRetry(joinPoint, method, retry, error);


        //2.2.4 抛出异常
        throw error;
    }

    @Autowired
    RetryRepository retryRepository;

    private void persistenceRetry(ProceedingJoinPoint joinPoint, Method method, LRetry retry, Throwable error) {

        //        1.判断
        if (retry.needJobRetry() && error instanceof RuntimeException) {
//        2.需要重试的参数
            String fullClassName = joinPoint.getTarget().getClass().getName();
            //com.dwyingyuan.retry.service.RetryServiceImpl  retryServiceImpl
            String className = StringUtils.uncapitalize(fullClassName.substring(fullClassName.lastIndexOf(".") + 1));
            RetryClass retryClass = RetryUtils.generateRetryClass(joinPoint, method, fullClassName, className);

//        3.保存DB
            RetryDTO retryDTO = RetryDTO.builder()
                    .classInfo(JSON.toJSONString(retryClass))
                    .retryTimes(0)
                    .memo(error.toString())
                    .build();
            retryRepository.insert(retryDTO);
        }


    }


}
