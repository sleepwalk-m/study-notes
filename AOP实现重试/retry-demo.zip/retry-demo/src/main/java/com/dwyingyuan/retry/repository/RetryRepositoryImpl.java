package com.dwyingyuan.retry.repository;

import com.dwyingyuan.retry.enums.*;
import com.dwyingyuan.retry.mapper.*;
import com.dwyingyuan.retry.model.dto.*;
import com.dwyingyuan.retry.model.entity.*;
import com.github.dozermapper.core.*;
import com.google.common.collect.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.util.*;

import javax.annotation.*;
import java.util.*;
import java.util.stream.*;

@Repository
public class RetryRepositoryImpl implements RetryRepository {


    @Resource
    RetryMapper retryMapper;

    @Autowired
    private Mapper mapper;

    @Override
    public int insert(RetryDTO retryDTO) {
        Retry retry = mapper.map(retryDTO, Retry.class);
        retry.setStatus(RetryStatusEnums.UN_DONE.getCode());
        retry.setCreatedOn(new Date());
        retry.setUpdatedOn(new Date());

        return retryMapper.insert(retry);
    }

    @Override
    public List<RetryDTO> findNeedRetry(Long maxId, Integer batchQueryLimitSize, Integer retryTimes) {
        List<Retry> needRetryList = retryMapper.findNeedRetryList(maxId, batchQueryLimitSize, retryTimes);
        if (CollectionUtils.isEmpty(needRetryList)) {
            return Lists.newArrayList();
        }
        return needRetryList.stream().map(c -> mapper.map(c, RetryDTO.class)).collect(Collectors.toList());
    }

    @Override
    public void increaseRetryTime(RetryDTO retryDTO) {
        Retry retry = mapper.map(retryDTO, Retry.class);
        retry.setRetryTimes(retryDTO.getRetryTimes() + 1);
        retryMapper.updateByPrimaryKey(retry);
    }

    @Override
    public void markRetrySuccess(RetryDTO retryDTO) {
        Retry retry = mapper.map(retryDTO, Retry.class);
        retry.setStatus(RetryStatusEnums.DONE.getCode());
        retryMapper.updateByPrimaryKey(retry);
    }

}