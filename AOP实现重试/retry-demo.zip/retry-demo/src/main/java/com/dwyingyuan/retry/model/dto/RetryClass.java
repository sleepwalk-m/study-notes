package com.dwyingyuan.retry.model.dto;

import lombok.*;

import java.io.*;
import java.util.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RetryClass implements Serializable {

    private String className;
    private String fullClassName;
    private String methodName;
    private LinkedHashMap<String, String> args;

}