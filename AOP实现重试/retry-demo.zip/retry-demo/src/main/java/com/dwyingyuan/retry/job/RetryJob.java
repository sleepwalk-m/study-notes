package com.dwyingyuan.retry.job;

import com.dwyingyuan.retry.service.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

/**
 * 微信公众号：笛舞音缘
 * Created by andy  on 2021-01-12.
 */
@Component
public class RetryJob {


    @Autowired
    RetryService retryService;


    public void execute() {
        System.out.println("job重试开始了。。。。。。");
        retryService.retryJob();
        System.out.println("job重试结束了。。。。。。");

    }
}
