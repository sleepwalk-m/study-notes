package com.dwyingyuan.retry;

import org.mybatis.spring.annotation.*;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;

/**
 * 微信公众号：笛舞音缘
 * Created by Andy on 2020-08-27.
 */
@SpringBootApplication
@MapperScan("com.dwyingyuan.retry.mapper")
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
