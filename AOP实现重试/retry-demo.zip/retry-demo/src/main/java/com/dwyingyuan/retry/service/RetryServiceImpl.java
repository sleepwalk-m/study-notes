package com.dwyingyuan.retry.service;

import com.alibaba.fastjson.*;
import com.dwyingyuan.retry.annotation.*;
import com.dwyingyuan.retry.context.*;
import com.dwyingyuan.retry.model.dto.*;
import com.dwyingyuan.retry.repository.*;
import com.dwyingyuan.retry.utils.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.util.*;

import java.lang.reflect.*;
import java.util.*;

/**
 * 微信公众号：笛舞音缘
 * Created by andy  on 2021-01-12.
 */
@Service
@Slf4j
public class RetryServiceImpl implements RetryService {


    @Override
    @LRetry(retryTimes = 3, needJobRetry = true)
    public void looklook(LookParamDTO lookParamDTO) {
        System.out.println("瞅一瞅  看一看");
//        int i = 2 / 0;
        System.out.println("服务器恢复正常了，你可以XXX");
    }


    @Autowired
    RetryRepository retryRepository;

    @Override
    public void retryJob() {

        while (true) {
            //        1.循环查找符合条件的数据
            List<RetryDTO> retryDTOList = retryRepository.findNeedRetry((long) 0, 20, 3);
            if (CollectionUtils.isEmpty(retryDTOList)) {
                break;
            }

            //不需要进入且 main
            RetryContext.setContext(Boolean.FALSE);
            //        2.循环结果集
            for (RetryDTO retryDTO : retryDTOList) {
                try {
                    //        3.组装反射需要的参数
                    RetryClass retryClass = JSON.parseObject(retryDTO.getClassInfo(), RetryClass.class);
                    String className = retryClass.getClassName();
                    String fullClassName = retryClass.getFullClassName();

                    Object classImpl = RetryUtils.getClassImpl(className);
                    Object[] args = RetryUtils.getArgs(retryClass);
                    Method method = RetryUtils.getMethod(retryClass, fullClassName);

                    //        4反射执行
                    method.invoke(classImpl, args);
                    //        5 成功-标记成成功
                    retryRepository.markRetrySuccess(retryDTO);

                } catch (Exception e) {
                    //        6失败-重试次数+1
                    retryRepository.increaseRetryTime(retryDTO);
                    log.error("job  重试失败了！！！！！", e);
                }
            }
            RetryContext.clear();

        }

    }
}
