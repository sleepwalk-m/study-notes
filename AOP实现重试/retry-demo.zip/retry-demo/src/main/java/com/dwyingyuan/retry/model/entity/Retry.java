package com.dwyingyuan.retry.model.entity;

import lombok.*;

import java.io.*;
import java.util.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Retry implements Serializable {
    private Long id;
    private Integer retryTimes;
    private String classInfo;
    private String memo;
    private Integer status;
    private String createdBy;
    private Date createdOn;
    private String updatedBy;
    private Date updatedOn;
    private Integer isDeleted;
}