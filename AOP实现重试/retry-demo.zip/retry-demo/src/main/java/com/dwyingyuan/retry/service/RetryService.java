package com.dwyingyuan.retry.service;

import com.dwyingyuan.retry.model.dto.*;

/**
 * 微信公众号：笛舞音缘
 * Created by andy  on 2021-01-12.
 */
public interface RetryService {


    /**
     * 瞧一瞧  看一看
     *
     * @param lookParamDTO
     */
    void looklook(LookParamDTO lookParamDTO);


    /**
     * 持久化重试
     */
    void retryJob();
}
