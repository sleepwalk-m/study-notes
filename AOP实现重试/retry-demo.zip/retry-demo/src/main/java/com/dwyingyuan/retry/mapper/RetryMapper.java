package com.dwyingyuan.retry.mapper;

import com.dwyingyuan.retry.model.entity.*;
import org.apache.ibatis.annotations.*;

import java.util.*;

@Mapper
public interface RetryMapper {

    int insert(Retry record);

    int updateByPrimaryKey(Retry record);

    List<Retry> findNeedRetryList(@Param("maxId") Long maxId,
                                  @Param("limit") Integer limit,
                                  @Param("maxRetryTimes") Integer maxRetryTimes);
}