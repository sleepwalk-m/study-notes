package com.dwyingyuan.retry;

import com.dwyingyuan.retry.job.*;
import com.dwyingyuan.retry.model.dto.*;
import com.dwyingyuan.retry.service.*;
import net.bytebuddy.asm.Advice.*;
import org.junit.*;
import org.junit.runner.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.test.context.junit4.*;


/**
 * 基础测试类
 * <p>
 * Created by Andy on 2020-01-12.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class RetryTest {


    @Autowired
    RetryService retryService;

    @Test
    public void test_retry() {
        LookParamDTO paramDTO = LookParamDTO.builder()
                .where("西湖")
                .where("??????")
                .time(1L)
                .build();
        retryService.looklook(paramDTO);
    }


    @Autowired
    RetryJob retryJob;

    @Test
    public void test_retry_job() {
        retryJob.execute();
    }
}
