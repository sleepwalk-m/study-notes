### 基于spring—aop的重试功能
## 学习目标

1.使用aop开发过什么功能？举个例子。

2.学会分析需求的简单套路。

## 一、问题场景：

当在12306买票的人特别多的时候，服务器有时候会提示你：当前服务繁忙，请稍后进行<font size=4 color="Red">重试</font>！然后我们就会重新点击购买，最终<font size=4 color="Red">买票成功</font>。

分析：

出现了什么问题？

买票没成功

怎么解决的？

重试

结果如何？

买到了票

在某个商城完成下单后，系统会通知下有业务。由于扣减库存是异步的，可能会操作失败，为了让业务最大可能性的<font size=4 color="Red">成功</font>，我们需要<font size=4 color="Red">重试</font>。![01](assets/01.png)

## 二、解决方案

对于上述的业务问题，我针对这类问题给出了一套通用的解决方案，分为内存重试和持久化重试两部分。

### 1）内存重试
* 解决方案及原理
我们基于spring-aop，定义一个切面，切入点为自定义的注解，对需要重试的方法**打上注解并设置相应参数**，当该方法被外部调用时，基于切面的**环绕特性**，切面会捕获方法抛出的异常，在环绕通知中重试该方法。

* 不足
内存重试是瞬间操作，如果当时有服务还没有恢复正常，那内存重试的结果就会是失败的。

### 2）持久化重试

* 解决方案及原理
持久化重试作为内存重试的一种补充，当切面中内存重试都失败后，继续提供重试的机制。
由于切面的特性，我们可以从joinPoint中获取该方法的调用现场(**类名、方法名、参数类型和具体参数**)，持久化到数据库中。
提供一个job来扫描**符合条件**的持久化的重试数据，由于方法的现场都保留了下来，通过spring上下文、java的反射调用便能模拟当时环境，达到重试的目的。
* 不足
持久化的方式比较重，并且使用场景有限。

## 三、具体实现

### 1）内存重试的实现

__流程图:__
 ![02](/Users/apple/Desktop/itheima/retry/assets/02.png)

依赖准备

```
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-configuration-processor</artifactId>
        <version>${spring-boot.version}</version>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-autoconfigure</artifactId>
        <version>${spring-boot.version}</version>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-aop</artifactId>
        <version>${spring-boot.version}</version>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
        <version>${spring-boot.version}</version>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter</artifactId>
        <version>${spring-boot.version}</version>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <version>${spring-boot.version}</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.mybatis.spring.boot</groupId>
        <artifactId>mybatis-spring-boot-starter</artifactId>
        <version>${mybatis-spring-boot-starter.version}</version>
    </dependency>
    <dependency>
        <groupId>org.apache.commons</groupId>
        <artifactId>commons-lang3</artifactId>
    </dependency>
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <version>1.18.10</version>
    </dependency>
    <dependency>
        <groupId>com.github.dozermapper</groupId>
        <artifactId>dozer-core</artifactId>
        <version>6.5.0</version>
    </dependency>
    <dependency>
        <groupId>com.alibaba</groupId>
        <artifactId>fastjson</artifactId>
        <version>1.2.54</version>
    </dependency>
    <dependency>
        <groupId>com.google.guava</groupId>
        <artifactId>guava</artifactId>
        <version>29.0-jre</version>
    </dependency>
    <!-- mysql-connector-java -->
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <version>8.0.15</version>
    </dependency>
</dependencies>
```

application.yaml

```
spring:
  application:
    name: retry-demo
  profiles:
    active: dev
server:
  port: 8080


mybatis:
  mapper-locations: classpath*:mappers/*.xml
```

application-dev.yaml

```
spring:
  datasource:
    url: jdbc:mysql://81.68.70.18:3306/study?zeroDateTimeBehavior=convertToNull&serverTimezone=Asia/Shanghai&autoReconnect=true&useUnicode=true&characterEncoding=utf-8&useSSL=false
    username: root
    password: 123456
    driver-class-name: com.mysql.cj.jdbc.Driver
    hikari:
      maximum-pool-size: 5
      auto-commit: true
      idle-timeout: 30000
      pool-name: DatebookHikariCP
      max-lifetime: 1800000
      connection-timeout: 30000
      connection-test-query: SELECT 1
```

#### 1.定义LRetry注解

```
/**
 * 微信公众号：笛舞音缘
 * Created by andy  on 2020-12-30.
 */
@Target(value = ElementType.METHOD)
@Retention(value = RetentionPolicy.RUNTIME)
public @interface LRetry {
    /**
     * |
     * 内存重试次数
     */
    int retryTimes();
}
```

#### 2.编写AOP切面类

```
@Aspect
@Component
public class RetryAspect {
    private final Logger log = LoggerFactory.getLogger(RetryAspect.class);
    
    @Autowired
    RetryRepository retryRepository;

    @Pointcut("@annotation(com.dwyingyuan.starter.annotation.LRetry)")
    public void retryPoint() {
    }

    @Around("retryPoint()")
    public Object handle(ProceedingJoinPoint joinPoint) throws Throwable {
        //判断是否需要进入切面重试
        if (isNeedRetry()) {
            return joinPoint.proceed();
        }
        //获取重试方法
        Method method = getMethod(joinPoint);
        Throwable error = null;
        //获取当前拦截方法的注解对象
        LRetry retry = getRetryAnnotation(joinPoint);
        //循环执行
        for (int i = 0; i < retry.retryTimes(); i++) {
            try {
                return joinPoint.proceed();
            } catch (Throwable t) {
                log.info("进入第{}次重试,方法:{}", i + 1, method.getName(), t);
                //失败抛出异常
                error = t;
            }
        }
        //持久化重试
        persistenceRetry(joinPoint, method, error, retry);
        //失败抛出异常
        throw error;
    }
```

```
private Method getMethod(ProceedingJoinPoint joinPoint) {
    MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
    return methodSignature.getMethod();
}
```

```
private LRetry getRetryAnnotation(ProceedingJoinPoint joinPoint) throws NoSuchMethodException {
        //1.获取方法签名
        Method method = getMethod(joinPoint);
        //2.获取对象
        LRetry retry = method.getAnnotation(LRetry.class);
        return retry;
}
```

### 2）持久化重试的实现

__流程图:__
 ![03](/Users/apple/Desktop/itheima/retry/assets/03.png)

####  1.表设计

```
-- auto-generated definition
create table retry
(
  id          bigint unsigned auto_increment
    primary key,
  class_info  text              not null comment '重试的方法及参数',
  retry_times int     default 0 not null comment '重试次数',
  status      int     default 0 not null comment '重试状态 0 未处理 1 处理完毕',
  memo        text              not null comment '备注',
  created_by  varchar(64)       null comment '创建人',
  created_on  datetime          null comment '创建时间',
  updated_by  varchar(64)       null comment '修改人',
  updated_on  datetime          null comment '修改时间',
  is_deleted  tinyint default 0 not null comment '删除标识'
)
  comment '重试表';
```

####  2.RetryMapper

```
@Mapper
public interface RetryMapper {
    int insert(Retry record);
    int updateByPrimaryKey(Retry record);
    List<Retry> findNeedRetryList(@Param("maxId") Long maxId,
                                  @Param("limit") Integer limit,
                                  @Param("maxRetryTimes") Integer maxRetryTimes);
}
```

####  3.RetryMapper.xml

```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.dwyingyuan.starter.mapper.RetryMapper">

    <resultMap id="BaseResultMap" type="com.dwyingyuan.starter.domain.entity.Retry">
        <id column="id" jdbcType="BIGINT" property="id"/>
        <result column="retry_times" jdbcType="INTEGER" property="retryTimes"/>
        <result column="status" jdbcType="INTEGER" property="status"/>
        <result column="created_by" jdbcType="VARCHAR" property="createdBy"/>
        <result column="created_on" jdbcType="TIMESTAMP" property="createdOn"/>
        <result column="updated_by" jdbcType="VARCHAR" property="updatedBy"/>
        <result column="updated_on" jdbcType="TIMESTAMP" property="updatedOn"/>
        <result column="is_deleted" jdbcType="TINYINT" property="isDeleted"/>
        <result column="class_info" jdbcType="LONGVARCHAR" property="classInfo"/>
        <result column="memo" jdbcType="LONGVARCHAR" property="memo"/>
    </resultMap>

    <sql id="Base_Column_List">
    `id`, `retry_times`, `status`, `created_by`, `created_on`, `updated_by`, `updated_on`, 
    `is_deleted`,`class_info`, `memo`
  </sql>

    <select id="selectByPrimaryKey" parameterType="java.lang.Long" resultMap="BaseResultMap">
        select
        <include refid="Base_Column_List"/>
        from retry
        where `id` = #{id,jdbcType=BIGINT}
    </select>

    <insert id="insert" keyColumn="id" keyProperty="id" parameterType="com.dwyingyuan.starter.domain.entity.Retry"
            useGeneratedKeys="true">
    insert into retry (
     `retry_times`,
      `status`,
      `created_by`,
      `created_on`,
      `updated_by`,
      `updated_on`,
      `is_deleted`,
      `class_info`,
       `memo`
      )
    values (
      #{retryTimes},
      #{status},
      #{createdBy},
      now(),
      #{updatedBy},
      now(),
      0,
      #{classInfo},
      #{memo}
      )
  </insert>

    <update id="updateByPrimaryKey" parameterType="com.dwyingyuan.starter.domain.entity.Retry">
    update retry
    set `retry_times` = #{retryTimes,jdbcType=INTEGER},
      `status` = #{status,jdbcType=INTEGER},
      `created_by` = #{createdBy,jdbcType=VARCHAR},
      `created_on` = #{createdOn,jdbcType=TIMESTAMP},
      `updated_by` = #{updatedBy,jdbcType=VARCHAR},
      `updated_on` = #{updatedOn,jdbcType=TIMESTAMP},
      `is_deleted` = #{isDeleted,jdbcType=TINYINT}
    where `id` = #{id,jdbcType=BIGINT}
  </update>

    <select id="findNeedRetryList" resultMap="BaseResultMap" parameterType="map">
        select
        <include refid="Base_Column_List"/>
        from retry
        <![CDATA[
        WHERE id>#{maxId}
        AND retry_times < #{maxRetryTimes}
        AND status = 0
        AND is_deleted = 0
        ORDER BY id ASC
        LIMIT #{limit};
        ]]>
    </select>

</mapper>
```

####  4.dto/entity

```
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Retry implements Serializable {
    private Long id;
    private Integer retryTimes;
    private String classInfo;
    private String memo;
    private Integer status;
    private String createdBy;
    private Date createdOn;
    private String updatedBy;
    private Date updatedOn;
    private Integer isDeleted;
}
```

```
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RetryClass implements Serializable {

    private String className;
    private String fullClassName;
    private String methodName;
    private LinkedHashMap<String, String> args;

}
```

```
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RetryDTO implements Serializable {
    private Long id;
    private Integer retryTimes;
    private String classInfo;
    private String memo;
    private Integer status;
    private String createdBy;
    private Date createdOn;
    private String updatedBy;
    private Date updatedOn;
    private Integer isDeleted;
}
```

####  5.枚举/常量

```
@Getter
public enum RetryStatusEnums {
    DONE(1, "处理完毕"),
    UN_DONE(0, "未处理");

    private int code;
    private String desc;

    private RetryStatusEnums(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }


}
```

####  6.自定义异常

```
public class RetryException extends RuntimeException {
    public RetryException() {
    }
    public RetryException(String message) {
        super(message);
    }
    public RetryException(String message, Throwable cause) {
        super(message, cause);
    }
}
```

####  7.Config类

```
@Configuration
public class DozerConfiguration {
    @Bean
    public Mapper mapper() {
        DozerBeanMapper mapper = (DozerBeanMapper) DozerBeanMapperBuilder.buildDefault();
        return mapper;
    }
}
```

####  9.工具类

```
@Component
public class Beans implements ApplicationContextAware {
    public static ApplicationContext applicationContext;
    @Override
    public void setApplicationContext(ApplicationContext ctx) throws BeansException {
        applicationContext = ctx;
    }

    public static ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    public static Object getBean(String name) {
        return applicationContext.getBean(name);
    }

    public static <T> T getType(String name) {
        return (T) applicationContext.getBean(name);
    }
    public static <T> T getBean(String name, Class<T> requiredType) {
        return applicationContext.getBean(name, requiredType);
    }
    public static <T> T getBean(Class<T> requiredType) {
        return applicationContext.getBean(requiredType);
    }
}
```

```
public class RetryUtils {

    public static Method getMethod(RetryClass retryClass, String className) throws RetryException {
        Map<String, String> args = retryClass.getArgs();
        Class[] argTypes = new Class[args.keySet().size()];
        try {
            generateMethodArgTypes(args, argTypes);
            Class clazz = Class.forName(className);
            for (Class c : clazz.getInterfaces()) {
                try {
                    return c.getMethod(retryClass.getMethodName(), argTypes);
                } catch (NoSuchMethodException e) {

                }
            }
        } catch (ClassNotFoundException e) {
            throw new RetryException(String.format("classNotFount,argTypes:[%s]", retryClass.getArgs()), e);
        }
        throw new RetryException(String.format("NoSuchMethodException,argTypes:[%s]", argTypes));

    }
    private static void generateMethodArgTypes(Map<String, String> args, Class[] argTypes) throws ClassNotFoundException {
        for (int i = 0; i < args.keySet().size(); i++) {
            String name = (String) args.keySet().toArray()[i];
            Class c = ClassUtils.getClass(name);
            argTypes[i] = c;
        }
    }

    /**
     * 从 ApplicationContext 获取bean
     * @param className
     * @return
     * @throws RetryException
     */
    public static Object getClassImpl(String className) throws RetryException {

        if (StringUtils.isBlank(className)) {
            throw new RetryException("className is blank");
        }
        if (Beans.getBean(className) == null) {
            throw new RetryException("can not find class");
        }
        return Beans.getBean(className);
    }

    public static Object[] getArgs(RetryClass retryClass) {

        Map<String, String> args = retryClass.getArgs();
        Class[] argTypes = new Class[args.keySet().size()];
        Object[] objects = new Object[args.keySet().size()];
        try {
            generateMethodArgTypes(args, argTypes);
        } catch (ClassNotFoundException e) {
            throw new RetryException(String.format("classNotFount,argTypes:[%s]", retryClass.getArgs()), e);
        }

        List<String> keys = Lists.newArrayList(args.keySet());
        for (int i = 0; i < keys.size(); i++) {
            objects[i] = JSON.parseObject(args.get(keys.get(i)), argTypes[i]);
        }
        return objects;

    }

    public static RetryClass generateRetryClass(ProceedingJoinPoint joinPoint, Method method,String fullClazzName, String className) {

        LinkedHashMap<String, String> args = new LinkedHashMap<>();
        RetryClass rc = RetryClass.builder()
                .className(className)
                .methodName(method.getName())
                .fullClassName(fullClazzName)
                .args(args)
                .build();
        Class<?>[] parameterTypes = method.getParameterTypes();

        if (parameterTypes.length == 0) {
            return rc;
        }

        for (int i = 0; i < parameterTypes.length; i++) {
            args.put(parameterTypes[i].getName(), JSON.toJSONString(joinPoint.getArgs()[i]));
        }
        rc.setArgs(args);
        return rc;
    }
}
```

#### 10.仓储层代码

```
public interface RetryRepository {

    int insert(RetryDTO re);

    List<RetryDTO> findNeedRetry(Long maxId, Integer batchQueryLimitSize, Integer retryTimes);

    void increaseRetryTime(RetryDTO retryDTO);

    void markRetrySuccess(RetryDTO retryDTO);


}
```

```
@Repository
public class RetryRepositoryImpl implements RetryRepository {


    @Resource
    RetryMapper retryMapper;

    @Autowired
    private Mapper mapper;

    @Override
    public int insert(RetryDTO retryDTO) {
        Retry retry = mapper.map(retryDTO, Retry.class);
        retry.setStatus(RetryStatusEnums.UN_DONE.getCode());
        retry.setCreatedOn(new Date());
        retry.setUpdatedOn(new Date());
        return retryMapper.insert(retry);
    }

    @Override
    public List<RetryDTO> findNeedRetry(Long maxId, Integer batchQueryLimitSize, Integer retryTimes) {
        List<Retry> needRetryList = retryMapper.findNeedRetryList(maxId, batchQueryLimitSize, retryTimes);
        if (CollectionUtils.isEmpty(needRetryList)) {
            return Lists.newArrayList();
        }
        return needRetryList.stream().map(c -> mapper.map(c, RetryDTO.class)).collect(Collectors.toList());
    }

    @Override
    public void increaseRetryTime(RetryDTO retryDTO) {
        Retry retry = mapper.map(retryDTO, Retry.class);
        retry.setRetryTimes(retryDTO.getRetryTimes() + 1);
        retryMapper.updateByPrimaryKey(retry);
    }

    @Override
    public void markRetrySuccess(RetryDTO retryDTO) {
        Retry retry = mapper.map(retryDTO, Retry.class);
        retry.setStatus(RetryStatusEnums.DONE.getCode());
        retryMapper.updateByPrimaryKey(retry);
    }

}
```

####  11.线程上下文

```
public class RetryContext {
    public static ThreadLocal<Boolean> retryContext = new InheritableThreadLocal<Boolean>();
    public static void setContext(Boolean isExecuteAspect) {
        retryContext.set(isExecuteAspect);
    }
    public static void clear() {
        retryContext.remove();
    }
}
```

####  12.重试参数持久化

```
//持久化重试
private void persistenceRetry(ProceedingJoinPoint joinPoint, Method method, 
																														Throwable error, 
																																LRetry retry) {
    String className = joinPoint.getTarget().getClass().getName();
    String simpleName = StringUtils.uncapitalize(
   														 className.substring(className.lastIndexOf(".") + 1));

    log.error(String.format("重试%d次失败,方法:%s",  retry.retryTimes(), 
    																							method.getName()), error);
    
    if (retry.needJobRetry() && error instanceof RetryException) {

        RetryClass rc = RetryUtils.generateRetryClass(joinPoint, method, clazzName);
        RetryDTO re = RetryDTO.builder()
                .classInfo(JSON.toJSONString(rc))
                .retryTimes(0)
                .memo(error.toString())
                .build();

        retryRepository.insert(re);
    }
}
```

```
//job处理核心逻辑
@Override
public void retryJobHandle() {
    logger.info("retryJobHandle.start..");
    //对于job重试的，不需要进入重试切面
    RetryContext.setContext(Boolean.FALSE);
    while (true) {
        Long maxId = 0L;
        List<RetryDTO> retryDTOList = retryRepository.findNeedRetry(maxId, 20, 3);
        if (CollectionUtils.isEmpty(retryDTOList)) {
            break;
        }
        for (RetryDTO retryDTO : retryDTOList) {
            logger.info("retry..start handle:" + retryDTO.getId());
            doRetry(retryDTO);
            logger.info("retry..end handle:" + retryDTO.getId());
        }
    }
    RetryContext.clear();
    logger.info("FailedEventHandleJob.end..");
}
```

#### 13.JOB处理类

```
// 我们的job方法，比如使用xxl-job
@Component
public class RetryJob {

    @Autowired
    RetryService retryService;

    public void execute() {
        System.out.println("重试JOB开始");
        retryService.retryJobHandle();
        System.out.println("重试JOB结束");
    }
}
```

 12.测试

```
@Test
public void test_2() {
    System.out.println("=====持久化重试开始测试=======");
    retryJob.execute();
    System.out.println("=====持久化重试测试结束=======");
}
```

## 四、使用样例

 ####  内存重试测试

```
//在需要重试的方法上添加注解
    @Override
    @LRetry(retryTimes = 3, needJobRetry = true)
    public void look(LookParamDTO lookParamDTO) {
        System.out.println("测试重试");
        int i = 6 / 0;
    }
```

```
@Autowired
private RetryService retryService;

@Test
public void test_1() {
    System.out.println("=====开始测试=======");
    retryService.look("RetryService");
    System.out.println("=====测试结束=======");

}
```

####  持久化重试测试

``` @Test
public void test_2() {
    System.out.println("=====持久化重试开始测试=======");
    retryJob.execute();
    System.out.println("=====持久化重试测试结束=======");
}
```

## 五、总结及展望（思考）

利用切面＋注解的方式来减少对代码的侵入，又能达到内存重试的效果。利用反射+JOB进行周期性重试，保障业务的成功概率。

持久化重试需要从spring上下文中获取类实例，所以只有被spring管理的实例才能被获取到，而且非常的重，适用的场景不是很多。

功能的演进方向：考虑不仅在自己系统中使用，在别的系统中引入POM依赖也可以用。