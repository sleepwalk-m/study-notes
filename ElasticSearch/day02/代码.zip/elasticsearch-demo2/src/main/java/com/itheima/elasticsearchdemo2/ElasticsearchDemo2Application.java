package com.itheima.elasticsearchdemo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElasticsearchDemo2Application {
    public static void main(String[] args) {
        SpringApplication.run(ElasticsearchDemo2Application.class, args);
    }
}
